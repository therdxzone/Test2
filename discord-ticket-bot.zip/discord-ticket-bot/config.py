"""config.py - all editable settings for the ticket bot.

Secrets (token, API key, model name) come from .env ONLY.
Discord IDs below are NOT secrets: edit them directly in this file.
Set an ID to 0 to disable that feature.
"""
import os

from dotenv import load_dotenv

load_dotenv()

# ----------------------------------------------------------------- secrets / env
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "")  # e.g. a free-tier Flash model
GUILD_ID = int(os.getenv("GUILD_ID", "0") or 0)  # optional: instant slash-command sync

# ----------------------------------------------------------------- branding
SERVER_NAME = "My Server"
WEBSITE = "https://example.com"

# ----------------------------------------------------------------- channels
LOG_CHANNEL_ID = 0            # transcripts, daily report, abuse log
TICKET_PANEL_CHANNEL_ID = 0   # where users are told to open tickets
INFO_CHANNEL_IDS = [0]        # channels scanned for knowledge (last 30 msgs each)

# Channels the AI may point users to with <#id>. name -> id + short description.
CHANNELS = {
    "vps-hosting": {"id": 0, "desc": "VPS plans, IPv4 plans and pricing"},
    "rules": {"id": 0, "desc": "Server rules"},
    "announcements": {"id": 0, "desc": "News and updates"},
}

# ----------------------------------------------------------------- ticket types
# category_id = category where tickets are created
# role_id     = staff role for that type (staff_apply -> manager role)
TICKET_TYPES = {
    "support": {
        "label": "Support", "emoji": "🛠️",
        "description": "Questions and technical help",
        "category_id": 0, "role_id": 0, "max_ai_replies": 6,
    },
    "billing": {
        "label": "Billing", "emoji": "💳",
        "description": "Orders, payments, refunds",
        "category_id": 0, "role_id": 0, "max_ai_replies": 6,
    },
    "staff_apply": {
        "label": "Staff Apply", "emoji": "📝",
        "description": "Apply to join the team",
        "category_id": 0, "role_id": 0,
        # 5 questions + summary needs more turns than the default 6
        "max_ai_replies": 10,
    },
}
ALL_STAFF_ROLE_IDS = {c["role_id"] for c in TICKET_TYPES.values() if c["role_id"]}

# ----------------------------------------------------------------- timers / limits
TIMEZONE = "Asia/Kolkata"
REPORT_HOUR = 20                 # daily report at 20:00 in TIMEZONE
USER_WARN_AFTER = 3600           # ping user after 1h of silence
USER_CLOSE_AFTER = 7200          # auto-close after 2h of silence
STAFF_PING_EVERY = 3600          # ping staff every hour when waiting on staff
CLAIMER_ESCALATE_AFTER = 7200    # ping whole role if claimer silent this long
KNOWLEDGE_REFRESH_MINUTES = 30
GENERAL_COOLDOWN = 8             # seconds per user for @mention chat
GEMINI_TIMEOUT = 40              # seconds

# abuse module
ABUSE_ENABLED = True
ABUSE_CHANNEL_IDS = []           # empty = every normal channel the bot can see
ABUSE_MIN_CONFIDENCE = 0.8
ABUSE_BATCH_MIN = 10             # send a batch when this many are queued...
ABUSE_BATCH_MAX = 20
ABUSE_MAX_WAIT = 60              # ...or when the oldest has waited this long (s)

# files
DB_PATH = "tickets.db"
KNOWLEDGE_FILE = "knowledge.md"
MAX_KNOWLEDGE_CHARS = 30000
MAX_SCAN_CHARS = 30000


def validate() -> list[str]:
    """Return a list of fatal problems (missing secrets)."""
    problems = []
    if not DISCORD_TOKEN:
        problems.append("DISCORD_TOKEN missing in .env")
    if not GEMINI_API_KEY:
        problems.append("GEMINI_API_KEY missing in .env")
    if not GEMINI_MODEL:
        problems.append("GEMINI_MODEL missing in .env")
    return problems
