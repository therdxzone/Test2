# Knowledge base (the AI's ONLY source of truth)
Edit this file, then run /sync_data. Only put facts you want the bot to state.

## About
- Server name: My Server
- Website: https://example.com

## Services
- VPS hosting: describe plans, specs and prices here (see #vps-hosting).
- IPv4 plans: describe availability and prices here.

## Payments
- Accepted methods: list them here.
- Refunds: handled by staff only (the bot never promises refunds).

## Support
- Hours: e.g. 10:00-22:00 IST
- Rules: link to #rules
